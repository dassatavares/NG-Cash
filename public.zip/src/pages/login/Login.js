import React, { useState } from "react";

// Boostrap
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

// CSS
import "./login.css";

// Components
import Cadastro from "../../components/cadastro/cadastro";

const Login = () => {
  const [IsActive, setIsActive] = useState(false);

  return (
    <>
    
      <Container>
        <Row>
        <div className="content">
          
          <Col xs={12} md={6}>
            <div className="content">
              <div className="welcome">
                <p>já pensou em estar com a maior carteira digital da nova geração?</p>
                <h1>A CARTEIRA DA NOVA GERAÇÃO.</h1>
                <br />
                <p>
                Somos a Nova Geração transformando o Futuro. <br /> 
                O novo é constante, construa conosco.
                </p>
                <br />
                <span> NG Cash © 2022</span>
              </div>
            </div>
          </Col>

          <Col xs={12} md={6}>
            <div className="content">
              {!IsActive && (
                <div className="login">
                  <h3>Login</h3>
                  <form>
                    <img
                      src="https://cdn.forbesmedia.cz/images/eyJ1IjoiXC91cGxvYWRzXC8yMDIxXC8wNFwvYmlsbC1nYXRlcy5qcGciLCJ3Ijo0MTYsInYiOiIxLjAifQ%3D%3D.jpg"
                      alt=""
                    />
                    <input type="email" placeholder="E-mail" required />
                    <input type="password" placeholder="Senha" required />
                    <button type="submit" className="button-1">
                      Login
                    </button>
                    <button
                      type="button"
                      className="button-2"
                      onClick={() => setIsActive(true)}
                    >
                      Cadastrar-se
                    </button>
                  </form>

                  <p>
                    <a href="www.google.com.br" className="password">
                      Esqueci minha senha
                    </a>
                  </p>
                </div>
              )}

              {IsActive && <Cadastro setIsActive={setIsActive} />}
            </div>
          </Col>

          </div>
        </Row>
      </Container>
    </>
  );
};

export default Login;
